'''#####-----Wizard Name-----#####'''
wiz_name = 'Your_Wizard_Name'

'''#####-----Wizard Plugin ID-----#####'''
wiz_plugin_id  = 'plugin.program.yourwizard'

